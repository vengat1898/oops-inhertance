public class Vehicles {
    public String name;
    public String model="m1";

    public String getModel(){
        return model;
    }
}
