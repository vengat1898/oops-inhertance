public class TwoWheelers extends Vehicles{
        public String seatCoverModel;

        public void doSomething(){

        }

}
