public class MainClass {

    public static void main(String[] args) {

        Yamaha yamaha= new Yamaha();
        yamaha.name="Yamaha";
       // yamaha.


        Honda honda= new Honda();
        honda.

        TwoWheelers twoWheelers= new TwoWheelers();
        twoWheelers.model="Hi";
        twoWheelers.getModel();
        twoWheelers.doSomething();




        Vehicles vehicles= new Vehicles();
        vehicles.getModel();
    }


}
