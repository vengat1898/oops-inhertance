public class Yamaha extends TwoWheelers{
    public String version;

    public boolean isTwoWheeler(){
        return true;
    }

}
